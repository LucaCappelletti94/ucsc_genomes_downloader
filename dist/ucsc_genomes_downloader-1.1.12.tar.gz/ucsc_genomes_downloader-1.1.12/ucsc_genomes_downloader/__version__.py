"""Current version of package ucsc_genomes_downloader"""
__version__ = "1.1.12"
