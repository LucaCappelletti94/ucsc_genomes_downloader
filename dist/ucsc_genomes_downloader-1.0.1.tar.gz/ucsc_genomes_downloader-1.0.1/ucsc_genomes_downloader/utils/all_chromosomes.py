all_chromosomes = [
    "chr{n}".format(n=n) for n in tuple(range(1, 23)) + ("X", "Y")
]